stack = []
x, y, z = 'x', 'y', 'z'
stack.append(x)
stack.append(y)
stack.append(z)
top = stack.pop()
print(top)
